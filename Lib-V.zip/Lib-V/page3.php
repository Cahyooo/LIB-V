<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LIB-V Virtual Librarian Chatbot</title>
    <style>
        /* ==================================== */
        /* 1. CSS Styling (Dioptimalkan untuk Chat) */
        /* ==================================== */

        :root {
            --color-bg-light: #C3E0E5;
            --color-bg-dark: #012B35; 
            --color-input: #A9D0D8;
            --color-text-dark: #1E3A42;
            --color-text-light: #FFFFFF;
            --color-send-icon: #778899;
            --color-bubble-user: #87CEEB; 
            --color-bubble-bot: #F0F8FF; 
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background-color: white; 
            width: 100vw;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        /* Container Utama (Full Screen) */
        .app-container {
            position: relative;
            width: 100%; 
            height: 100%; 
            background-color: var(--color-bg-light); 
            overflow: hidden;
            display: flex;
            flex-direction: column; 
            border-radius: 0; 
            box-shadow: none; 
        }

        /* Tombol Kembali (Dengan Animasi Hover) */
        .back-button {
            position: absolute;
            top: 15px; 
            left: 15px;
            background-color: #FFFFFF;
            color: var(--color-text-dark);
            border: none;
            width: 40px; 
            height: 40px;
            border-radius: 8px; /* Bentuk kotak membulat */
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24px;
            cursor: pointer;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            z-index: 10;
            font-weight: bold;
            line-height: 1;
            transition: all 0.2s ease-in-out;
        }

        /* Efek Hover/Animasi */
        .back-button:hover {
            background-color: var(--color-bg-dark); 
            color: var(--color-text-light); 
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.2); 
            transform: scale(1.05); 
        }

        /* Header (Dikecilkan untuk Tampilan Chat) */
        .chat-header {
            background-color: var(--color-bg-dark);
            padding: 15px 15px 15px 70px; /* Padding disesuaikan */
            display: flex;
            flex-direction: row; 
            justify-content: flex-start; 
            align-items: center;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            position: relative;
            z-index: 5;
        }
        
        .illustration-area {
            display: none; 
            margin: 0;
        }

        .welcome-text {
            font-size: 1.4rem; 
            font-weight: 700;
            color: var(--color-text-light);
            line-height: 1.3;
            margin: 0;
            margin-left: 15px; 
        }

        /* Area Pesan/Chat Log */
        .chat-log {
            flex-grow: 1;
            padding: 20px; 
            overflow-y: auto;
            background-color: var(--color-bg-light);
        }

        /* Styling Pesan (NORMAL) */
        .message {
            margin-bottom: 15px;
            display: flex;
            align-items: flex-start;
            transition: opacity 0.5s ease-out, transform 0.5s ease-out;
        }
        
        /* Keadaan Awal Animasi */
        .message.fade-in-start {
            opacity: 0;
            transform: translateY(10px); 
        }

        .message.user {
            justify-content: flex-end;
            /* Tambahkan padding di kanan untuk memberi ruang pada ikon pengguna */
            padding-right: 35px; 
            position: relative;
        }
        
        /* Avatar Pengguna (CSS Pseudo-element) */
        .message.user::after {
            content: '';
            position: absolute;
            top: 0; 
            right: 0; /* Posisikan di kanan */
            width: 30px; 
            height: 30px;
            border-radius: 50%;
            background-color: var(--color-bubble-user); 
            background-image: url('Pic/ava.jpg'); 
            background-size: cover;
            background-position: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        .message.bot,
        .message.typing-indicator { 
            justify-content: flex-start;
            padding-left: 35px; 
            position: relative;
        }

        /* Ikon Bot (CSS Pseudo-element) */
        .message.bot::before,
        .message.typing-indicator::before { 
            content: '';
            position: absolute;
            top: 0; 
            left: 0;
            width: 30px; 
            height: 30px;
            border-radius: 50%;
            background-color: var(--color-bg-dark); 
            background-image: url('Pic/logo.png'); 
            background-size: cover;
            background-position: center;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }


        .message-bubble {
            max-width: 75%;
            padding: 10px 14px; 
            border-radius: 18px;
            line-height: 1.4;
            color: var(--color-text-dark);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .message.user .message-bubble {
            background-color: var(--color-bubble-user);
            border-bottom-right-radius: 5px;
        }

        .message.bot .message-bubble {
            background-color: var(--color-bubble-bot);
            border-bottom-left-radius: 5px;
        }
        
        /* === Animasi Mengetik (Typing Indicator) === */
        .typing-indicator .message-bubble {
            background-color: var(--color-bubble-bot);
            width: 60px; /* Lebar kecil untuk tiga titik */
            padding: 10px 14px;
            border-radius: 18px;
            display: flex;
            justify-content: space-around;
            align-items: center;
            min-height: 40px; 
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .typing-indicator .dot {
            width: 8px;
            height: 8px;
            background-color: var(--color-text-dark);
            border-radius: 50%;
            opacity: 0.3;
            animation: dot-pulse 1.5s infinite ease-in-out;
        }

        .typing-indicator .dot:nth-child(2) {
            animation-delay: 0.2s;
        }

        .typing-indicator .dot:nth-child(3) {
            animation-delay: 0.4s;
        }

        @keyframes dot-pulse {
            0% {
                opacity: 0.3;
                transform: scale(0.9);
            }
            50% {
                opacity: 1;
                transform: scale(1.1);
            }
            100% {
                opacity: 0.3;
                transform: scale(0.9);
            }
        }
        
        .input-area {
            position: relative;
            width: 100%;
            padding: 15px 20px; 
            background-color: var(--color-bg-light);
            box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.1);
        }

        textarea#user-input {
            width: 100%;
            min-height: 40px; 
            max-height: 100px; 
            padding: 10px 60px 10px 15px; 
            background-color: var(--color-input);
            border: none;
            border-radius: 20px;
            font-size: 1rem; 
            color: var(--color-text-dark);
            resize: vertical; 
            outline: none;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        .send-button {
            position: absolute;
            right: 35px; 
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            padding: 5px;
            border-radius: 50%;
        }

        .send-button svg {
            color: var(--color-send-icon);
            transform: rotate(-45deg); 
            width: 24px; 
            height: 24px;
            filter: drop-shadow(0 1px 1px rgba(0,0,0,0.1));
        }
    </style>
</head>
<body>

    <div class="app-container">
        <button class="back-button" aria-label="Kembali">
            &lt;
        </button>

        <header class="chat-header">
            <div class="illustration-area">
                </div>
            <div class="header-content">
                <h1 class="welcome-text">
                    LIB–V Virtual Librarian
                </h1>
            </div>
        </header>

        <div class="chat-log" id="chat-log">
            <div class="message bot">
                <div class="message-bubble">Halo! Saya LIB-V, asisten perpustakaan virtual Anda. Apa yang bisa saya bantu hari ini?</div>
            </div>
        </div>

        <div class="input-area">
            <textarea id="user-input" placeholder="Ketik pesan Anda di sini..."></textarea>
            <button class="send-button" id="send-button" aria-label="Kirim Pesan">
                <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/>
                </svg>
            </button>
        </div>
    </div>

    <script>
        const chatLog = document.getElementById('chat-log');
        const userInput = document.getElementById('user-input');
        const sendButton = document.getElementById('send-button');
        const backButton = document.querySelector('.back-button');

        // Konstanta Teks (Menggantikan languageData)
        const INITIAL_GREETING = 'Halo! Saya LIB-V, asisten perpustakaan virtual Anda. Apa yang bisa saya bantu hari ini?';
        const BOT_RESPONSE_PREFIX = 'Saya menerima pertanyaan Anda:';
        const BOT_RESPONSE_SUFFIX = '. Mencari jawaban...';


        // Fungsi Tombol Kembali (ke page1.php)
        if (backButton) {
            backButton.addEventListener('click', function() {
                window.location.href = 'page1.php'; 
            });
        }
        
        // Fungsi untuk menambahkan pesan ke DOM
        function addMessage(text, sender) {
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message', sender, 'fade-in-start'); 
            
            const bubbleDiv = document.createElement('div');
            bubbleDiv.classList.add('message-bubble');
            bubbleDiv.textContent = text;
            
            messageDiv.appendChild(bubbleDiv);
            chatLog.appendChild(messageDiv);
            
            chatLog.scrollTop = chatLog.scrollHeight;
            
            // Pemicu Animasi Fade-in
            setTimeout(() => {
                messageDiv.classList.remove('fade-in-start');
            }, 50); 
        }

        // Fungsi untuk membuat dan menampilkan typing indicator
        function addTypingIndicator() {
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('message', 'typing-indicator');
            messageDiv.id = 'typing-indicator'; 
            messageDiv.classList.add('fade-in-start'); 

            const bubbleDiv = document.createElement('div');
            bubbleDiv.classList.add('message-bubble');
            
            // Tambahkan 3 titik (dots)
            bubbleDiv.innerHTML = '<div class="dot"></div><div class="dot"></div><div class="dot"></div>';
            
            messageDiv.appendChild(bubbleDiv);
            chatLog.appendChild(messageDiv);
            chatLog.scrollTop = chatLog.scrollHeight;
            
            // Pemicu Animasi Fade-in Indicator
            setTimeout(() => {
                messageDiv.classList.remove('fade-in-start');
            }, 50); 
        }

        // Fungsi untuk menghapus typing indicator
        function removeTypingIndicator() {
            const indicator = document.getElementById('typing-indicator');
            if (indicator) {
                indicator.remove();
            }
        }
        
        // Fungsi Kirim Pesan
        function handleSendMessage() {
            const text = userInput.value.trim();
            if (text === '') return;

            addMessage(text, 'user');
            userInput.value = '';

            addTypingIndicator(); 
            
            setTimeout(() => {
                removeTypingIndicator(); 
                
                // Gunakan konstanta teks
                const botResponse = `${BOT_RESPONSE_PREFIX} "${text}"${BOT_RESPONSE_SUFFIX}`;
                addMessage(botResponse, 'bot');
            }, 1500); 
        }

        // Event Listeners
        sendButton.addEventListener('click', handleSendMessage);

        userInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
            }
        });
    </script>

</body>
</html>